package homelibrary.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

enum PublicationType
{
    BOOK,
    JOURNAL;
}

/**
 *
 * @author Kay Jay O'Nail
 */
public class AddServlet extends HttpServlet
{
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(false);
        if (session != null)
        {
            String userId = (String) session.getAttribute("id");
            String title = request.getParameter("title");
            String publicationDate = request.getParameter("publication-date");
            String condition = request.getParameter("condition");
            String publicationType = request.getParameter("publication-type");
            String isxn = request.getParameter("isbn/issn");
            String authors = request.getParameter("authors");

            PublicationType type = proofType(publicationType);
            Integer year = null;
            try
            {
                year = Integer.valueOf(publicationDate);
            }
            catch (NumberFormatException nf)
            {
            }
            if (type != null && year != null)
            {
                try (PrintWriter out = response.getWriter())
                {
                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title>Servlet AddServlet</title>");
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<p>ID=%s</p>".formatted(userId));
                    out.print("<p>");

                    String query = """
                    INSERT INTO
                            app.publications (title, owner_id, publication_date, condition, publication_type, %s)
                    VALUES
                            ('%s', %s, '%s-01-01', '%s', '%s', '%s')

                    """.formatted(
                            type == PublicationType.BOOK ? "isbn" : "issn",
                            title, userId, year, condition, type.toString().toLowerCase(), isxn
                    );

                    try
                    {
                        Driver driver = new org.postgresql.Driver();
                        DriverManager.registerDriver(driver);

                        String dbUrl = DatabaseConnectionData.DATABASE_URL;
                        String dbUsername = DatabaseConnectionData.DATABASE_USERNAME;
                        String dbPassword = DatabaseConnectionData.DATABASE_PASSWORD;

                        try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword); Statement statement = connection.createStatement())
                        {
                            statement.executeUpdate(query);
                        }
                    }
                    catch (SQLException sql)
                    {
                        out.println(sql);
                    }

                    query = "SELECT p.id FROM app.publications p WHERE %s = '%s'"
                            .formatted(type == PublicationType.BOOK ? "isbn" : "issn", isxn);

                    Integer id;
                    try
                    {
                        Driver driver = new org.postgresql.Driver();
                        DriverManager.registerDriver(driver);

                        String dbUrl = DatabaseConnectionData.DATABASE_URL;
                        String dbUsername = DatabaseConnectionData.DATABASE_USERNAME;
                        String dbPassword = DatabaseConnectionData.DATABASE_PASSWORD;

                        try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword); Statement statement = connection.createStatement())
                        {
                            ResultSet results = statement.executeQuery(query);
                            if (results.next())
                            {
                                id = results.getInt("id");
                                out.print(id);
                            }
                        }
                    }
                    catch (SQLException sql)
                    {
                        out.print(sql);
                    }

                    out.println("</p>");
                    out.println("</body>");
                    out.println("</html>");
                }
            }
            else
            {

            }
        }
    }

    private PublicationType proofType(String type)
    {
        PublicationType result = null;
        if (type.toUpperCase().equals(PublicationType.BOOK.name().toUpperCase()))
        {
            result = PublicationType.BOOK;
        }
        else if (type.toUpperCase().equals(PublicationType.JOURNAL.name().toUpperCase()))
        {
            result = PublicationType.JOURNAL;
        }
        return result;
    }

    private Integer addPublication(String title, String ownerId, int year, String condition, PublicationType type, String isxn)
    {
        String query = """
                INSERT INTO
                        app.publications (title, owner_id, publication_date, condition, publication_type, %s)
                VALUES
                        (%s, %s, %s, %s, %s, %s)

                """.formatted(
                type == PublicationType.BOOK ? "isbn" : "issn",
                title, ownerId, year, condition, type.toString().toLowerCase(), isxn
        );

        try
        {
            Driver driver = new org.postgresql.Driver();
            DriverManager.registerDriver(driver);

            String dbUrl = DatabaseConnectionData.DATABASE_URL;
            String dbUsername = DatabaseConnectionData.DATABASE_USERNAME;
            String dbPassword = DatabaseConnectionData.DATABASE_PASSWORD;

            try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword); Statement statement = connection.createStatement())
            {
                statement.executeUpdate(query);
            }
        }
        catch (SQLException sql)
        {

        }

        query = "SELECT p.id FROM app.publications p WHERE %s = %s"
                .formatted(type == PublicationType.BOOK ? "isbn" : "issn", isxn);

        Integer id = null;
        try
        {
            Driver driver = new org.postgresql.Driver();
            DriverManager.registerDriver(driver);

            String dbUrl = DatabaseConnectionData.DATABASE_URL;
            String dbUsername = DatabaseConnectionData.DATABASE_USERNAME;
            String dbPassword = DatabaseConnectionData.DATABASE_PASSWORD;
            
            try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword); Statement statement = connection.createStatement())
            {
                ResultSet results = statement.executeQuery(query);
                if (results.next())
                {
                    id = results.getInt("app.publications.id");
                }
            }
        }
        catch (SQLException sql)
        {

        }

        return id;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

}
