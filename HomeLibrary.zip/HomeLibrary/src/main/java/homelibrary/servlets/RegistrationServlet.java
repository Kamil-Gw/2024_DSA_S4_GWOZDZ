package homelibrary.servlets;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Kay Jay O'Nail
 */
public class RegistrationServlet extends HttpServlet
{
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password1 = request.getParameter("password");
        String password2 = request.getParameter("confirm");

        List<String> errorMessages = new ArrayList<>();
        if (!isUniqueUsername(username))
        {
            errorMessages.add("The username is already in use.");
        }
        if (!isCorrectPassword(password1))
        {
            errorMessages.add("The password is incorrect; the requirements are:<br>"
                              + "<ul><li>at least 8 characters <b>and</b></li>"
                              + "<li>at least one lowercase letter <b>and</b></li>"
                              + "<li>at least one uppercase letter <b>and</b></li>"
                              + "<li>at least one digit <b>and</b></li>"
                              + "<li>at least one special character.</li></ul>");
        }
        if (!password2.equals(password1))
        {
            errorMessages.add("The passwords do not match.");
        }
        if (!isUniqueEmail(email))
        {
            errorMessages.add("The email is already in use.");
        }

        if (errorMessages.isEmpty())
        {
            registerUser(username, email, password2);
            HttpSession session = request.getSession(true);
            session.setAttribute("username", username);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/home");
            dispatcher.forward(request, response);
        }
        else
        {
            try (PrintWriter out = response.getWriter())
            {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println(" <title>Home Library &middot; Register Again</title>");
                out.println(" <style>");
                out.println("  .DefaultBox");
                out.println("  {");
                out.println("   border: 2px solid black;");
                out.println("   margin: 20px;");
                out.println("   padding: 20px;");
                out.println("  }");
                out.println("  .Error");
                out.println("  {");
                out.println("   border: 2px solid #D00000;");
                out.println("   margin: 10 px;");
                out.println("   padding: 10 px;");
                out.println("  }");
                out.println(" </style>");
                out.println("</head>");
                out.println("<body>");
                out.println(" <h1>Home Library &middot; Registration</h1>");
                out.println(" <p>Errors:</p>");
                for (var message : errorMessages)
                {
                    out.println("<div class=\"Error\">" + message + "</div><br>");
                }
                out.println(" <h2>Try again</h2>");
                out.println(" <div class=\"DefaultBox\">");
                out.println("  <form action=\"register\" method=\"post\">");
                out.println("   <table>");
                out.println("    <tr>");
                out.println("     <th align=\"right\">Username:</th>");
                out.println("     <td><input name=\"username\" type=\"text\" required/></td>");
                out.println("    </tr>");
                out.println("    <tr>");
                out.println("     <th align=\"right\">Email:</th>");
                out.println("     <td><input name=\"email\" type=\"text\" required/></td>");
                out.println("    </tr>");
                out.println("    <tr>");
                out.println("     <th align=\"right\">Password:</th>");
                out.println("     <td><input name=\"password\" type=\"password\" required/></td>");
                out.println("    </tr>");
                out.println("    <tr>");
                out.println("     <th align=\"right\">Confirm:</th>");
                out.println("     <td><input name=\"confirm\" type=\"password\" required/></td>");
                out.println("    </tr>");
                out.println("   </table><br>");
                out.println("   <input name=\"accept\" type=\"checkbox\" required/>I accept the regulations and terms.<br>");
                out.println("   <input type=\"submit\" value=\"Register\"/>");
                out.println("  </form><br>");
                out.println("  <p>If you already have an account, <a href=\"index.html\">log in</a>.</p>");
                out.println(" </div>");
                out.println("</body>");
                out.println("</html>");
            }
        }
    }

    private boolean isCorrectPassword(String password)
    {
        boolean correct;
        if (password.length() < 8)
        {
            correct = false;
        }
        else
        {
            boolean lowercase = false;
            boolean uppercase = false;
            boolean digit = false;
            boolean special = false;
            for (int i = 0; i < password.length(); ++i)
            {
                char character = password.charAt(i);
                if (character >= 'a' && character <= 'z')
                {
                    lowercase = true;
                }
                else if (character >= 'A' && character <= 'Z')
                {
                    uppercase = true;
                }
                else if (character >= '0' && character <= '9')
                {
                    digit = true;
                }
                else if (character >= '!' && character <= '~')
                {
                    special = true;
                }
                if (lowercase && uppercase && digit && special)
                {
                    break;
                }
            }
            correct = lowercase && uppercase && digit && special;
        }
        return correct;
    }

    private boolean isUniqueUsername(String username)
    {
        boolean success = false;
        try
        {
            Driver driver = new org.postgresql.Driver();
            DriverManager.registerDriver(driver);

            String dbUrl = DatabaseConnectionData.DATABASE_URL;
            String dbUsername = DatabaseConnectionData.DATABASE_USERNAME;
            String dbPassword = DatabaseConnectionData.DATABASE_PASSWORD;

            try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword); Statement statement = connection.createStatement())
            {
                String query = "SELECT * FROM app.users u"
                               + " WHERE u.username = \'" + username + "\'";
                ResultSet results = statement.executeQuery(query);
                success = !results.next();
            }
        }
        catch (SQLException sql)
        {
        }
        return success;
    }

    private boolean isUniqueEmail(String email)
    {
        boolean success = false;
        try
        {
            Driver driver = new org.postgresql.Driver();
            DriverManager.registerDriver(driver);

            String dbUrl = DatabaseConnectionData.DATABASE_URL;
            String dbUsername = DatabaseConnectionData.DATABASE_USERNAME;
            String dbPassword = DatabaseConnectionData.DATABASE_PASSWORD;

            try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword); Statement statement = connection.createStatement())
            {
                String query = "SELECT * FROM app.users u"
                               + " WHERE u.email = \'" + email + "\'";
                ResultSet results = statement.executeQuery(query);
                success = !results.next();
            }
        }
        catch (SQLException sql)
        {
        }
        return success;
    }

    private boolean registerUser(String username, String email, String password)
    {
        boolean success = false;
        try
        {
            Driver driver = new org.postgresql.Driver();
            DriverManager.registerDriver(driver);

            String dbUrl = DatabaseConnectionData.DATABASE_URL;
            String dbUsername = DatabaseConnectionData.DATABASE_USERNAME;
            String dbPassword = DatabaseConnectionData.DATABASE_PASSWORD;

            try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword); Statement statement = connection.createStatement())
            {
                String query = "INSERT INTO app.users (username, email, password, role) VALUES "
                               + "(\'" + username + "\', \'" + email + "\', \'" + password + "\', \'user\')";
                int rows = statement.executeUpdate(query);
                success = (rows == 1);
            }
        }
        catch (SQLException sql)
        {

        }
        return success;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

}
