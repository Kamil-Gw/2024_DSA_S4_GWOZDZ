package homelibrary.servlets;

/**
 *
 * @author Kay Jay O'Nail
 */
public class DatabaseConnectionData
{
    public static final String DATABASE_URL = "";
    public static final String DATABASE_USERNAME = "";
    public static final String DATABASE_PASSWORD = "";
}
