package homelibrary.model;

/**
 *
 * @author Kay Jay O'Nail
 */
public class Publication
{

}
